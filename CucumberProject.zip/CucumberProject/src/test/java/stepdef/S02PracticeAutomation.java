package stepdef;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class S02PracticeAutomation {

	WebDriver driver;
	String act, exp="https://practicetestautomation.com/logged-in-successfully/";
	@Given("User on practice automation login page")
	public void user_on_practice_automation_login_page() {
	    driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    driver.get("https://practicetestautomation.com/practice-test-login/");
	    
	}

	@When("Enter the correct username")
	public void enter_the_correct_username() {
		driver.findElement(By.xpath("//input[@id='username']")).sendKeys("student");
	    
	}

	@When("Enter the correct password")
	public void enter_the_correct_password() {
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Password123");

	}

	@When("click on login button")
	public void click_on_login_button() {
		driver.findElement(By.xpath("//button[@id='submit']")).click();

	}

	@Then("user should successfully login page")
	public void user_should_successfully_login_page() throws InterruptedException {
		Thread.sleep(2000);
		act =driver.getCurrentUrl();
	   if(act.equals(exp))
	   {
		   driver.findElement(By.xpath("//a[@class='wp-block-button__link has-text-color has-background has-very-dark-gray-background-color']")).click();
	   }
	   
	 //  driver.close();
	}
}
