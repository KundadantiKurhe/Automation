package stepdef;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;

public class S01GoogleTitlePage {
	WebDriver driver;
	String act, exp="Google";
	@Given("User is on google page")
	public void user_is_on_google_page() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.google.co.in/");
	   
	}

	@When("Read the title of page")
	public void read_the_title_of_page() {
	    act = driver.getTitle();
	}

	@Then("The title should be {string}")
	public void the_title_should_be(String string) {
	   if(act.equals(exp))
	   {
		   System.out.println("The page of title is Google");
	   }else {
		   System.out.println("Wrong result");

	   }
	}
}
